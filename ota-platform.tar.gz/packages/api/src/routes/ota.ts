import { Router } from 'express';
import { checkUpdate } from '../controllers/ota/checkUpdate';

const router = Router();

// POST /api/v1/ota/check-update
router.post('/check-update', checkUpdate);

export default router;
