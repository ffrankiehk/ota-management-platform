import { Request, Response } from 'express';
import { Application, Release } from '../../models';
import { compareVersions } from '@ota-platform/shared';
import { CheckUpdateRequest, CheckUpdateResponse } from '@ota-platform/shared';

export const checkUpdate = async (req: Request, res: Response) => {
  try {
    const body = req.body as Partial<CheckUpdateRequest>;

    const bundleId = body.bundleId;
    const platform = body.platform;
    const currentVersion = body.currentVersion;

    if (!bundleId || !platform || !currentVersion) {
      return res.status(400).json({
        success: false,
        message: 'bundleId, platform and currentVersion are required',
        timestamp: new Date().toISOString(),
      } satisfies CheckUpdateResponse);
    }

    const application = await Application.findOne({
      where: {
        bundle_id: bundleId,
        platform,
        is_active: true,
      },
    });

    if (!application) {
      return res.status(404).json({
        success: false,
        message: 'Application not found',
        timestamp: new Date().toISOString(),
      } satisfies CheckUpdateResponse);
    }

    const release = await Release.findOne({
      where: {
        application_id: application.id,
        status: 'active',
      },
      order: [['created_at', 'DESC']],
    });

    if (!release) {
      return res.json({
        success: true,
        data: { hasUpdate: false },
        message: 'No active releases found',
        timestamp: new Date().toISOString(),
      } satisfies CheckUpdateResponse);
    }

    const compare = compareVersions(currentVersion, release.version);
    const hasUpdate = compare < 0;

    if (!hasUpdate) {
      return res.json({
        success: true,
        data: { hasUpdate: false },
        message: 'You are on the latest version',
        timestamp: new Date().toISOString(),
      } satisfies CheckUpdateResponse);
    }

    const response: CheckUpdateResponse = {
      success: true,
      data: {
        hasUpdate: true,
        release: {
          id: release.id,
          version: release.version,
          bundleUrl: release.bundle_url,
          bundleHash: release.bundle_hash,
          bundleSize: Number(release.bundle_size),
          isMandatory: release.is_mandatory,
          releaseNotes: release.release_notes || '',
        },
      },
      message: 'Update available',
      timestamp: new Date().toISOString(),
    };

    return res.json(response);
  } catch (error: any) {
    console.error('Error in checkUpdate:', error);
    const response: CheckUpdateResponse = {
      success: false,
      message: 'Internal server error',
      error: error?.message || 'Unknown error',
      timestamp: new Date().toISOString(),
    } as any;
    return res.status(500).json(response);
  }
};
