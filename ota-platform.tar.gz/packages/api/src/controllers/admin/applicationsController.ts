import { Request, Response } from 'express';
import { Application, Organization, Release } from '../../models';

// GET /api/v1/admin/applications
export const listApplications = async (req: Request, res: Response) => {
  try {
    const applications = await Application.findAll({
      include: [
        {
          model: Organization,
          as: 'organization',
          attributes: ['id', 'name', 'slug'],
        },
        {
          model: Release,
          as: 'releases',
          attributes: ['id', 'version', 'status', 'released_at'],
        },
      ],
      order: [['created_at', 'DESC']],
    });

    const data = applications.map((app) => {
      const plain: any = app.toJSON();
      const latestRelease = (plain.releases || []).find((r: any) => r.status === 'active') ||
        (plain.releases || [])[0] ||
        null;

      return {
        id: plain.id,
        name: plain.name,
        bundleId: plain.bundle_id,
        platform: plain.platform,
        isActive: plain.is_active,
        currentVersion: plain.current_version || (latestRelease ? latestRelease.version : null),
        organization: plain.organization
          ? { id: plain.organization.id, name: plain.organization.name, slug: plain.organization.slug }
          : null,
        latestRelease: latestRelease
          ? {
              id: latestRelease.id,
              version: latestRelease.version,
              status: latestRelease.status,
              releasedAt: latestRelease.released_at,
            }
          : null,
      };
    });

    return res.json({
      success: true,
      data,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in listApplications:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error?.message || 'Unknown error',
      timestamp: new Date().toISOString(),
    });
  }
};

// POST /api/v1/admin/applications
export const createApplication = async (req: Request, res: Response) => {
  try {
    const { name, bundleId, platform, organizationId } = req.body;

    // Validate required fields
    if (!name || !bundleId || !platform) {
      return res.status(400).json({
        success: false,
        message: 'name, bundleId, and platform are required',
        timestamp: new Date().toISOString(),
      });
    }

    // Validate platform
    if (!['ios', 'android', 'both'].includes(platform)) {
      return res.status(400).json({
        success: false,
        message: 'platform must be ios, android, or both',
        timestamp: new Date().toISOString(),
      });
    }

    // Get organization (use first one if not specified)
    let orgId = organizationId;
    if (!orgId) {
      const org = await Organization.findOne();
      if (!org) {
        return res.status(400).json({
          success: false,
          message: 'No organization found. Please create an organization first.',
          timestamp: new Date().toISOString(),
        });
      }
      orgId = org.id;
    }

    // Check if application already exists
    const existing = await Application.findOne({
      where: { organization_id: orgId, bundle_id: bundleId, platform },
    });
    if (existing) {
      return res.status(409).json({
        success: false,
        message: `Application with bundle ID ${bundleId} and platform ${platform} already exists`,
        timestamp: new Date().toISOString(),
      });
    }

    // Create application
    const application = await Application.create({
      organization_id: orgId,
      name,
      bundle_id: bundleId,
      platform,
      is_active: true,
    });

    const plain: any = application.toJSON();

    return res.status(201).json({
      success: true,
      data: {
        id: plain.id,
        name: plain.name,
        bundleId: plain.bundle_id,
        platform: plain.platform,
        isActive: plain.is_active,
        createdAt: plain.created_at,
      },
      message: 'Application created successfully',
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in createApplication:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error?.message || 'Unknown error',
      timestamp: new Date().toISOString(),
    });
  }
};

// PUT /api/v1/admin/applications/:id
export const updateApplication = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, bundleId, platform, isActive } = req.body;

    const application = await Application.findByPk(id);
    if (!application) {
      return res.status(404).json({
        success: false,
        message: 'Application not found',
        timestamp: new Date().toISOString(),
      });
    }

    // Update fields if provided
    if (name !== undefined) application.set('name', name);
    if (bundleId !== undefined) application.set('bundle_id', bundleId);
    if (platform !== undefined) {
      if (!['ios', 'android', 'both'].includes(platform)) {
        return res.status(400).json({
          success: false,
          message: 'platform must be ios, android, or both',
          timestamp: new Date().toISOString(),
        });
      }
      application.set('platform', platform);
    }
    if (isActive !== undefined) application.set('is_active', isActive);

    await application.save();

    const plain: any = application.toJSON();

    return res.json({
      success: true,
      data: {
        id: plain.id,
        name: plain.name,
        bundleId: plain.bundle_id,
        platform: plain.platform,
        isActive: plain.is_active,
        updatedAt: plain.updated_at,
      },
      message: 'Application updated successfully',
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in updateApplication:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error?.message || 'Unknown error',
      timestamp: new Date().toISOString(),
    });
  }
};

// DELETE /api/v1/admin/applications/:id
export const deleteApplication = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const application = await Application.findByPk(id);
    if (!application) {
      return res.status(404).json({
        success: false,
        message: 'Application not found',
        timestamp: new Date().toISOString(),
      });
    }

    // Delete associated releases first
    await Release.destroy({ where: { application_id: id } });

    // Delete the application
    await application.destroy();

    return res.json({
      success: true,
      message: 'Application deleted successfully',
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in deleteApplication:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error?.message || 'Unknown error',
      timestamp: new Date().toISOString(),
    });
  }
};

// GET /api/v1/admin/applications/:id
export const getApplicationById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const application = await Application.findByPk(id, {
      include: [
        {
          model: Organization,
          as: 'organization',
          attributes: ['id', 'name', 'slug'],
        },
        {
          model: Release,
          as: 'releases',
          attributes: [
            'id',
            'version',
            'build_number',
            'bundle_url',
            'bundle_hash',
            'bundle_size',
            'min_app_version',
            'release_notes',
            'rollout_percentage',
            'is_mandatory',
            'status',
            'released_at',
            'created_at',
          ],
          order: [['created_at', 'DESC']],
        },
      ],
    });

    if (!application) {
      return res.status(404).json({
        success: false,
        message: 'Application not found',
        timestamp: new Date().toISOString(),
      });
    }

    const plain: any = application.toJSON();

    const data = {
      id: plain.id,
      name: plain.name,
      bundleId: plain.bundle_id,
      platform: plain.platform,
      isActive: plain.is_active,
      currentVersion: plain.current_version,
      createdAt: plain.created_at,
      updatedAt: plain.updated_at,
      organization: plain.organization
        ? { id: plain.organization.id, name: plain.organization.name, slug: plain.organization.slug }
        : null,
      releases: (plain.releases || []).map((r: any) => ({
        id: r.id,
        version: r.version,
        buildNumber: r.build_number,
        bundleUrl: r.bundle_url,
        bundleHash: r.bundle_hash,
        bundleSize: r.bundle_size,
        minAppVersion: r.min_app_version,
        releaseNotes: r.release_notes,
        rolloutPercentage: r.rollout_percentage,
        isMandatory: r.is_mandatory,
        status: r.status,
        releasedAt: r.released_at,
        createdAt: r.created_at,
      })),
    };

    return res.json({
      success: true,
      data,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in getApplicationById:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error?.message || 'Unknown error',
      timestamp: new Date().toISOString(),
    });
  }
};

// POST /api/v1/admin/applications/:id/releases
export const createRelease = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const {
      version,
      buildNumber,
      bundleUrl,
      bundleHash,
      bundleSize,
      minAppVersion,
      releaseNotes,
      rolloutPercentage = 0,
      isMandatory = false,
      status = 'draft',
    } = req.body;

    // Validate required fields
    if (!version || !bundleUrl || !bundleHash || !bundleSize) {
      return res.status(400).json({
        success: false,
        message: 'version, bundleUrl, bundleHash, and bundleSize are required',
        timestamp: new Date().toISOString(),
      });
    }

    // Check if application exists
    const application = await Application.findByPk(id);
    if (!application) {
      return res.status(404).json({
        success: false,
        message: 'Application not found',
        timestamp: new Date().toISOString(),
      });
    }

    // Check if version already exists for this application
    const existingRelease = await Release.findOne({
      where: { application_id: id, version },
    });
    if (existingRelease) {
      return res.status(409).json({
        success: false,
        message: `Release version ${version} already exists for this application`,
        timestamp: new Date().toISOString(),
      });
    }

    // Create the release
    const release = await Release.create({
      application_id: id,
      version,
      build_number: buildNumber || 1,
      bundle_url: bundleUrl,
      bundle_hash: bundleHash,
      bundle_size: bundleSize,
      min_app_version: minAppVersion || null,
      release_notes: releaseNotes || null,
      rollout_percentage: rolloutPercentage,
      is_mandatory: isMandatory,
      status,
      released_at: status === 'active' ? new Date() : null,
    });

    const plain: any = release.toJSON();

    return res.status(201).json({
      success: true,
      data: {
        id: plain.id,
        version: plain.version,
        buildNumber: plain.build_number,
        bundleUrl: plain.bundle_url,
        bundleHash: plain.bundle_hash,
        bundleSize: plain.bundle_size,
        minAppVersion: plain.min_app_version,
        releaseNotes: plain.release_notes,
        rolloutPercentage: plain.rollout_percentage,
        isMandatory: plain.is_mandatory,
        status: plain.status,
        releasedAt: plain.released_at,
        createdAt: plain.created_at,
      },
      message: 'Release created successfully',
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in createRelease:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error?.message || 'Unknown error',
      timestamp: new Date().toISOString(),
    });
  }
};

// PUT /api/v1/admin/releases/:releaseId
export const updateRelease = async (req: Request, res: Response) => {
  try {
    const { releaseId } = req.params;
    const {
      version,
      buildNumber,
      bundleUrl,
      bundleHash,
      bundleSize,
      minAppVersion,
      releaseNotes,
      rolloutPercentage,
      isMandatory,
      status,
    } = req.body;

    const release = await Release.findByPk(releaseId);
    if (!release) {
      return res.status(404).json({
        success: false,
        message: 'Release not found',
        timestamp: new Date().toISOString(),
      });
    }

    // Update fields if provided
    if (version !== undefined) release.set('version', version);
    if (buildNumber !== undefined) release.set('build_number', buildNumber);
    if (bundleUrl !== undefined) release.set('bundle_url', bundleUrl);
    if (bundleHash !== undefined) release.set('bundle_hash', bundleHash);
    if (bundleSize !== undefined) release.set('bundle_size', bundleSize);
    if (minAppVersion !== undefined) release.set('min_app_version', minAppVersion);
    if (releaseNotes !== undefined) release.set('release_notes', releaseNotes);
    if (rolloutPercentage !== undefined) release.set('rollout_percentage', rolloutPercentage);
    if (isMandatory !== undefined) release.set('is_mandatory', isMandatory);
    if (status !== undefined) {
      release.set('status', status);
      // Set released_at when status changes to active
      if (status === 'active' && !release.get('released_at')) {
        release.set('released_at', new Date());
      }
    }

    await release.save();

    const plain: any = release.toJSON();

    return res.json({
      success: true,
      data: {
        id: plain.id,
        version: plain.version,
        buildNumber: plain.build_number,
        bundleUrl: plain.bundle_url,
        bundleHash: plain.bundle_hash,
        bundleSize: plain.bundle_size,
        minAppVersion: plain.min_app_version,
        releaseNotes: plain.release_notes,
        rolloutPercentage: plain.rollout_percentage,
        isMandatory: plain.is_mandatory,
        status: plain.status,
        releasedAt: plain.released_at,
        updatedAt: plain.updated_at,
      },
      message: 'Release updated successfully',
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in updateRelease:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error?.message || 'Unknown error',
      timestamp: new Date().toISOString(),
    });
  }
};

// DELETE /api/v1/admin/releases/:releaseId
export const deleteRelease = async (req: Request, res: Response) => {
  try {
    const { releaseId } = req.params;

    const release = await Release.findByPk(releaseId);
    if (!release) {
      return res.status(404).json({
        success: false,
        message: 'Release not found',
        timestamp: new Date().toISOString(),
      });
    }

    await release.destroy();

    return res.json({
      success: true,
      message: 'Release deleted successfully',
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in deleteRelease:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error?.message || 'Unknown error',
      timestamp: new Date().toISOString(),
    });
  }
};
