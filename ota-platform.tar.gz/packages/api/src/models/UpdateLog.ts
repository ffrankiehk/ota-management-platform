import { DataTypes, Model, Optional } from 'sequelize';
import { sequelize } from '../config/database';

interface UpdateLogAttributes {
  id: string;
  device_id: string;
  release_id: string;
  action: string;
  status: 'success' | 'failed' | 'in_progress';
  error_message?: string | null;
  created_at?: Date;
  updated_at?: Date;
}

interface UpdateLogCreationAttributes
  extends Optional<
    UpdateLogAttributes,
    'id' | 'error_message' | 'created_at' | 'updated_at'
  > {}

export class UpdateLog
  extends Model<UpdateLogAttributes, UpdateLogCreationAttributes>
  implements UpdateLogAttributes
{
  public id!: string;
  public device_id!: string;
  public release_id!: string;
  public action!: string;
  public status!: 'success' | 'failed' | 'in_progress';
  public error_message!: string | null;
  public readonly created_at!: Date;
  public readonly updated_at!: Date;
}

UpdateLog.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    device_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    release_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    action: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    error_message: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    sequelize,
    tableName: 'update_logs',
    modelName: 'UpdateLog',
  }
);
