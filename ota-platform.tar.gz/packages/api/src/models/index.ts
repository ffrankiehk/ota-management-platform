import { sequelize } from '../config/database';
import { Organization } from './Organization';
import { Application } from './Application';
import { Release } from './Release';
import { Device } from './Device';
import { UpdateLog } from './UpdateLog';
import { User } from './User';

// Define associations
Organization.hasMany(Application, { foreignKey: 'organization_id', as: 'applications' });
Application.belongsTo(Organization, { foreignKey: 'organization_id', as: 'organization' });

Organization.hasMany(User, { foreignKey: 'organization_id', as: 'users' });
User.belongsTo(Organization, { foreignKey: 'organization_id', as: 'organization' });

Application.hasMany(Release, { foreignKey: 'application_id', as: 'releases' });
Release.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Application.hasMany(Device, { foreignKey: 'application_id', as: 'devices' });
Device.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Device.hasMany(UpdateLog, { foreignKey: 'device_id', as: 'updateLogs' });
UpdateLog.belongsTo(Device, { foreignKey: 'device_id', as: 'device' });

Release.hasMany(UpdateLog, { foreignKey: 'release_id', as: 'updateLogs' });
UpdateLog.belongsTo(Release, { foreignKey: 'release_id', as: 'release' });

export {
  sequelize,
  Organization,
  Application,
  Release,
  Device,
  UpdateLog,
  User,
};
