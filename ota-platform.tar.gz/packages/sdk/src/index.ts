// Core client
export { OTAClient } from './OTAClient';

// React hooks
export { useOTAUpdate } from './useOTAUpdate';

// React context/provider
export { OTAProvider, useOTA } from './OTAProvider';

// UI components
export { UpdatePrompt } from './UpdatePrompt';

// Types
export type {
  OTAConfig,
  UpdateInfo,
  DownloadProgress,
  OTAState,
  OTAError,
  CheckUpdateParams,
  CheckUpdateResponse,
} from './types';
