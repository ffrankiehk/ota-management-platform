/**
 * OTA SDK Configuration
 */
export interface OTAConfig {
  /** Base URL of the OTA API server */
  apiUrl: string;
  /** Application bundle ID (e.g., com.company.app) */
  bundleId: string;
  /** Platform: 'ios' | 'android' */
  platform: 'ios' | 'android';
  /** Current app version (e.g., '1.0.0') */
  appVersion: string;
  /** Current bundle version (e.g., '1.0.0') */
  currentBundleVersion: string;
  /** Optional: Device unique identifier */
  deviceId?: string;
  /** Optional: Check interval in milliseconds (default: 1 hour) */
  checkInterval?: number;
  /** Optional: Auto-check on app start (default: true) */
  autoCheck?: boolean;
}

/**
 * Update information returned from the API
 */
export interface UpdateInfo {
  available: boolean;
  version?: string;
  bundleUrl?: string;
  bundleHash?: string;
  bundleSize?: number;
  releaseNotes?: string;
  isMandatory?: boolean;
  minAppVersion?: string;
}

/**
 * Download progress information
 */
export interface DownloadProgress {
  bytesDownloaded: number;
  totalBytes: number;
  percent: number;
}

/**
 * OTA Update state
 */
export type OTAState =
  | 'idle'
  | 'checking'
  | 'available'
  | 'downloading'
  | 'verifying'
  | 'ready'
  | 'error';

/**
 * OTA Error
 */
export interface OTAError {
  code: string;
  message: string;
}

/**
 * Check update request parameters
 */
export interface CheckUpdateParams {
  bundleId: string;
  platform: 'ios' | 'android';
  currentVersion: string;
  appVersion: string;
  deviceId?: string;
}

/**
 * Check update API response
 */
export interface CheckUpdateResponse {
  success: boolean;
  data?: {
    updateAvailable: boolean;
    currentVersion: string;
    latestVersion?: string;
    downloadUrl?: string;
    bundleHash?: string;
    bundleSize?: number;
    releaseNotes?: string;
    isMandatory?: boolean;
    minAppVersion?: string;
  };
  message?: string;
}
